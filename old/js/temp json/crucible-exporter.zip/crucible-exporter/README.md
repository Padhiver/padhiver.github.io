# Crucible Babele Exporter

Module indépendant. Ne fait qu'exporter, ne traduit pas.

## Utilisation

Console Foundry ou macro :
```js
CrucibleExporter.open()
```

---

## ➕ Ajouter un nouveau type à exporter

**Étape 1** — Créez `config/item-weapon.json` :
```json
{
    "docType": "Item",
    "subType": "weapon",
    "fields": [
        "name",
        "system.description",
        "system.actions[].name",
        "system.actions[].description"
    ]
}
```

**Étape 2** — Ajoutez `"item-weapon.json"` dans la liste `CONFIG_FILES` au début de `exporter.js` :
```js
const CONFIG_FILES = [
    "item-talent.json",
    "item-weapon.json",   // ← ajout
    ...
];
```

C'est tout.

---

## Syntaxe des chemins

| Syntaxe | Signification |
|---|---|
| `name` | Champ racine simple |
| `system.description` | Chemin pointé |
| `system.actions[].name` | Tableau : extrait `.name` de chaque élément |
| `system.actions[].effects[].name` | Tableau imbriqué |
| `description` | Racine (pour les affixes) |

---

## Onglet "Analyser un document"

1. Exportez un document depuis Foundry : clic-droit sur un item dans un compendium → **Exporter JSON**
2. Ouvrez l'exporteur → onglet **Analyser**
3. Glissez-déposez le fichier `.json`
4. Cochez les champs souhaités, renseignez `docType` et `subType`
5. Cliquez **Générer** → télécharge le fichier de config prêt à l'emploi
6. Placez-le dans `config/` et ajoutez son nom dans `CONFIG_FILES`

---

## Structure

```
crucible-exporter/
├── module.json
├── macro.js                     ← CrucibleExporter.open()
├── scripts/
│   └── exporter.js              ← Tout le code (ConfigLoader, Extractor, Analyzer, UI)
└── config/
    ├── item-talent.json
    ├── item-spell.json
    ├── item-consumable.json
    ├── item-affix.json
    ├── actor-character.json
    ├── actor-npc.json
    └── journalentry-default.json
```
