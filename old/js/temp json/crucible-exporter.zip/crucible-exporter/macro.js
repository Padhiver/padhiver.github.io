// Macro Foundry — copiez ce contenu dans une macro de type "script"
CrucibleExporter.open();
