/**
 * =============================================================================
 *  Crucible Babele Exporter
 *  scripts/exporter.js
 * =============================================================================
 *
 *  Un seul fichier. Trois responsabilités clairement séparées :
 *
 *    1. ConfigLoader  — charge et met en cache les fichiers config/*.json
 *    2. Extractor     — lit un document Foundry et en extrait les champs
 *                       définis dans une config
 *    3. Analyzer      — reçoit un JSON brut glissé-déposé, parcourt sa
 *                       structure et propose les champs à cocher pour
 *                       générer une config
 *    4. ExporterApp   — interface ApplicationV2 (UI complète)
 *
 *  UTILISATION (console Foundry ou macro) :
 *      new ExporterApp().render(true)
 *
 * =============================================================================
 */

// =============================================================================
//  1. CONFIG LOADER
//  Charge tous les fichiers config/*.json du module au démarrage.
//  Chaque fichier déclare : docType, subType, fields[]
// =============================================================================

const ConfigLoader = (() => {

    // Cache : Map<"docType:subType" | "docType:default", configObject>
    const _cache = new Map();

    /**
     * Charge tous les JSON du dossier config/ et les met en cache.
     * Appelé une fois dans le hook "ready".
     */
    const load = async () => {
        // On récupère la liste des fichiers depuis module.json n'étant pas possible
        // simplement, on utilise une liste des fichiers connus + fallback fetch.
        // FoundryVTT n'expose pas de readdir côté client, on liste les configs
        // connues via un manifeste léger intégré ici.
        // ➕ Pour ajouter une config : ajoutez son nom de fichier dans CONFIG_FILES.
        const CONFIG_FILES = [
            "item-talent.json",
            "item-spell.json",
            "item-consumable.json",
            "item-affix.json",
            "actor-character.json",
            "actor-npc.json",
            "journalentry-default.json",
            // ➕ Ajoutez vos fichiers ici
        ];

        const base = `modules/crucible-exporter/config/`;
        for (const file of CONFIG_FILES) {
            try {
                const res  = await fetch(`${base}${file}`);
                const conf = await res.json();
                const key  = _key(conf.docType, conf.subType);
                _cache.set(key, conf);
                console.log(`CrucibleExporter | Config chargée : ${key}`);
            } catch (e) {
                console.warn(`CrucibleExporter | Impossible de charger ${file}`, e);
            }
        }
    };

    /** Construit la clé de cache */
    const _key = (docType, subType) =>
        `${(docType ?? "").toLowerCase()}:${(subType ?? "default").toLowerCase()}`;

    /**
     * Retourne la config pour un docType + subType donnés.
     * Repli sur "docType:default" si le subType exact n'existe pas.
     */
    const get = (docType, subType) => {
        const specific = _cache.get(_key(docType, subType));
        if (specific) return specific;
        return _cache.get(_key(docType, "default")) ?? null;
    };

    /** Liste toutes les configs chargées */
    const list = () => Array.from(_cache.values());

    return { load, get, list };

})();


// =============================================================================
//  2. EXTRACTOR
//  Lit un document Foundry et en extrait les valeurs selon une config.
//
//  FORMAT DES CHEMINS dans config.fields :
//    "name"                       → champ racine simple
//    "system.description"         → chemin pointé
//    "system.actions[].name"      → tableau : extrait .name de chaque élément
//    "system.actions[].effects[].name" → tableau imbriqué
//    "pages[].text.content"       → tableau de pages avec sous-chemin
//
//  La notation "[]" signifie "parcourir ce tableau".
// =============================================================================

const Extractor = (() => {

    // --------------------------------------------------------------------------
    //  Lecture d'une valeur via un chemin (gère les tableaux avec [])
    // --------------------------------------------------------------------------

    /**
     * Extrait la valeur au chemin donné depuis un objet.
     * Retourne undefined si vide/absent.
     */
    const _read = (obj, path) => {
        if (!obj || !path) return undefined;
        const parts = path.split(".");
        let current = obj;

        for (const part of parts) {
            if (current === null || current === undefined) return undefined;

            if (part.endsWith("[]")) {
                // Tableau : on délègue au collecteur
                const arrKey = part.slice(0, -2);
                const arr = _toArray(current[arrKey] ?? current);
                return arr; // sera traité par _extractArrayField
            }

            current = current[part];
        }

        return _nonEmpty(current) ? current : undefined;
    };

    /** Normalise n'importe quelle collection en tableau JS */
    const _toArray = (v) => {
        if (!v) return [];
        if (Array.isArray(v)) return v;
        if (v instanceof Map) return Array.from(v.values());
        if (typeof v[Symbol.iterator] === "function") return Array.from(v);
        if (typeof v === "object") return Object.values(v);
        return [];
    };

    /** Retourne false si la valeur est vide / whitespace */
    const _nonEmpty = (v) => {
        if (v === null || v === undefined) return false;
        if (typeof v === "string") return v.trim().length > 0;
        if (typeof v === "object") return Object.keys(v).length > 0;
        return true;
    };

    // --------------------------------------------------------------------------
    //  Construction de la sortie à partir d'une config
    // --------------------------------------------------------------------------

    /**
     * Regroupe les chemins du tableau config.fields en "groupes" :
     *  - champs racine simples      → { type:"simple",  path }
     *  - champs de tableau          → { type:"array",   arrayPath, subPaths[] }
     *
     * Exemple pour ["system.actions[].name", "system.actions[].description"] :
     *  → un groupe array { arrayPath:"system.actions", subPaths:["name","description"] }
     */
    const _groupPaths = (fields) => {
        const groups  = [];
        const arrays  = new Map(); // arrayPath → group

        for (const field of fields) {
            const bracketIdx = field.indexOf("[]");
            if (bracketIdx === -1) {
                // Champ simple
                groups.push({ type: "simple", path: field });
            } else {
                // Champ tableau
                const arrayPath = field.slice(0, bracketIdx);
                const remainder = field.slice(bracketIdx + 2).replace(/^\./, ""); // enlève le "." initial

                if (!arrays.has(arrayPath)) {
                    const g = { type: "array", arrayPath, subPaths: [] };
                    arrays.set(arrayPath, g);
                    groups.push(g);
                }
                if (remainder) arrays.get(arrayPath).subPaths.push(remainder);
            }
        }
        return groups;
    };

    /**
     * Extrait un champ tableau et retourne l'objet de sortie Babele.
     * Utilise l'id ou le name de chaque élément comme clé.
     *
     * Gère les sous-tableaux imbriqués (ex: effects[].name).
     */
    const _extractArray = (docData, group) => {
        const arr = _toArray(_read(docData, group.arrayPath + "[]"));
        if (!arr.length) return undefined;

        // On ré-applique _groupPaths sur les subPaths pour gérer l'imbrication
        const subGroups = _groupPaths(group.subPaths);
        const result    = {};

        arr.forEach((el, idx) => {
            if (!el) return;
            const key = el.id ?? el._id ?? el.name ?? String(idx);
            const out = {};

            for (const sg of subGroups) {
                if (sg.type === "simple") {
                    const val = foundry.utils.getProperty(el, sg.path);
                    if (_nonEmpty(val)) out[sg.path.split(".").pop()] = val;
                } else {
                    // Sous-tableau imbriqué (ex: effects[].name)
                    const sub = _extractArray(el, sg);
                    if (sub) {
                        const fieldName = sg.arrayPath.split(".").pop();
                        out[fieldName] = sub;
                    }
                }
            }

            if (Object.keys(out).length) result[key] = out;
        });

        return Object.keys(result).length ? result : undefined;
    };

    /**
     * Extrait tous les champs définis dans la config depuis un document.
     * Retourne l'objet de traduction Babele.
     */
    const extract = (doc, config) => {
        const docData = doc.toObject ? doc.toObject() : doc;
        const groups  = _groupPaths(config.fields ?? []);
        const out     = {};

        for (const group of groups) {

            if (group.type === "simple") {
                const leafKey = group.path.split(".").pop();
                const val     = foundry.utils.getProperty(docData, group.path);
                if (_nonEmpty(val)) out[leafKey] = val;

            } else {
                const fieldName = group.arrayPath.split(".").pop();
                const extracted = _extractArray(docData, group);
                if (extracted) out[fieldName] = extracted;
            }
        }

        return out;
    };

    /**
     * Exporte un pack complet selon les configs chargées.
     * Retourne { label, folders, entries } prêt pour saveDataToFile.
     */
    const exportPack = async (pack) => {
        const documents = await pack.getDocuments();
        if (!documents.length) return null;

        const packDocType = pack.metadata.type;
        const entries     = {};
        const folders     = {};

        // Collecte des dossiers
        const collectFolders = (f) => {
            if (!f) return;
            folders[f.name] = f.name;
            f.children?.forEach(c => c.folder && collectFolders(c.folder));
        };
        pack.folders?.forEach(f => collectFolders(f));

        for (const doc of documents) {
            const subType = doc.type ?? "default";
            const config  = ConfigLoader.get(packDocType, subType);

            if (!config) {
                console.warn(`CrucibleExporter | Pas de config pour ${packDocType}:${subType} — doc ignoré : ${doc.name}`);
                continue;
            }

            let translation = extract(doc, config);

            // Items embarqués (actor avec exportItems:true)
            if (config.exportItems && doc.items?.size > 0) {
                const itemsOut = {};
                doc.items.forEach(item => {
                    const ic = ConfigLoader.get("Item", item.type);
                    if (ic) itemsOut[item.name] = extract(item, ic);
                });
                if (Object.keys(itemsOut).length) translation.items = itemsOut;
            }

            // Pages de JournalEntry (gérées via le champ pages[].*)
            // Déjà couvert par le système générique ci-dessus.

            if (entries[doc.name]) {
                foundry.utils.mergeObject(entries[doc.name], translation, { recursive: true });
            } else {
                entries[doc.name] = translation;
            }
        }

        // Tri alphabétique
        const sorted = Object.keys(entries)
            .sort((a, b) => a.localeCompare(b))
            .reduce((acc, k) => { acc[k] = entries[k]; return acc; }, {});

        return { label: pack.metadata.label, folders, entries: sorted };
    };

    return { extract, exportPack };

})();


// =============================================================================
//  3. ANALYZER
//  Reçoit un JSON brut (un document exporté depuis Foundry) et
//  parcourt récursivement sa structure pour proposer tous les chemins
//  disponibles sous forme d'arbre à cocher.
//
//  L'utilisateur coche ce qu'il veut → génère le JSON de config.
// =============================================================================

const Analyzer = (() => {

    /**
     * Parcourt récursivement un objet et retourne la liste de tous les chemins
     * qui mènent à une valeur textuelle non vide.
     *
     * Retourne : [{ path: "system.description", value: "...", isArray: false }, ...]
     */
    const analyze = (obj, prefix = "", depth = 0) => {
        if (!obj || typeof obj !== "object" || depth > 8) return [];

        const results = [];

        // Cas tableau
        if (Array.isArray(obj)) {
            if (obj.length === 0) return [];
            // On analyse le premier élément pour déduire la structure
            const sample = obj[0];
            if (!sample || typeof sample !== "object") return [];
            const subPaths = analyze(sample, "", depth + 1);
            for (const sp of subPaths) {
                results.push({
                    path:    prefix ? `${prefix}[].${sp.path}` : `${sp.path}`,
                    sample:  sp.sample,
                    isArray: true,
                });
            }
            return results;
        }

        // Cas objet
        for (const [key, val] of Object.entries(obj)) {
            const fullPath = prefix ? `${prefix}.${key}` : key;

            if (val === null || val === undefined) continue;

            if (typeof val === "string") {
                if (val.trim().length > 0) {
                    results.push({ path: fullPath, sample: val.slice(0, 80), isArray: false });
                }
            } else if (Array.isArray(val)) {
                if (val.length > 0 && typeof val[0] === "object") {
                    const subPaths = analyze(val[0], "", depth + 1);
                    for (const sp of subPaths) {
                        results.push({
                            path:    `${fullPath}[].${sp.path}`,
                            sample:  sp.sample,
                            isArray: true,
                        });
                    }
                }
            } else if (typeof val === "object") {
                const sub = analyze(val, fullPath, depth + 1);
                results.push(...sub);
            }
        }

        return results;
    };

    /**
     * Génère le JSON de config à partir d'une liste de chemins sélectionnés.
     */
    const generateConfig = (docType, subType, selectedPaths) => ({
        docType,
        subType,
        fields: ["name", ...selectedPaths.filter(p => p !== "name")],
    });

    return { analyze, generateConfig };

})();


// =============================================================================
//  4. EXPORTER APP  (ApplicationV2)
//  Interface avec deux onglets :
//    • "Export"   — liste des packs + cases à cocher
//    • "Analyser" — glisser-déposer un JSON pour générer une config
// =============================================================================

class ExporterApp extends foundry.applications.api.ApplicationV2 {

    constructor(options = {}) {
        super(options);
        this._tab         = "export";   // onglet actif
        this._analyzed    = null;       // résultat de l'analyse en cours
        this._analyzeType = { docType: "Item", subType: "" };
    }

    static DEFAULT_OPTIONS = {
        id:  "crucible-exporter",
        tag: "form",
        window: {
            title:          "Crucible — Babele Exporter",
            icon:           "fa-solid fa-file-export",
            resizable:      true,
            contentClasses: ["standard-form"],
        },
        position: { width: 720, height: 820 },
        actions: {
            doExport:   ExporterApp._doExport,
            doAnalyze:  ExporterApp._doAnalyze,
            genConfig:  ExporterApp._genConfig,
            switchTab:  ExporterApp._switchTab,
        },
    };

    // -------------------------------------------------------------------------
    //  Rendu HTML complet (pas de HBS : tout est inline)
    // -------------------------------------------------------------------------
    async _prepareContext(options) {
        return {
            ...(await super._prepareContext(options)),
            tab:       this._tab,
            groupedPacks: this._buildPackList(),
            analyzed:  this._analyzed,
            analyzeType: this._analyzeType,
        };
    }

    _buildPackList() {
        return game.packs.reduce((acc, p) => {
            let label = p.metadata.type;
            if (p.metadata.type === "Item" && p.index.size > 0) {
                const first = p.index.values().next().value;
                if (first?.type) label = `Item · ${first.type[0].toUpperCase()}${first.type.slice(1)}`;
            }
            (acc[label] ??= []).push({ id: p.metadata.id, label: p.metadata.label, count: p.index.size });
            return acc;
        }, {});
    }

    async _renderHTML(context, options) {
        return { form: ExporterApp._buildHTML(context) };
    }

    _replaceHTML(result, content, options) {
        content.innerHTML = result.form;
        this._activateListeners(content);
    }

    // -------------------------------------------------------------------------
    //  Listeners (drag & drop + sélection)
    // -------------------------------------------------------------------------
    _activateListeners(html) {
        // Tout / Rien
        html.querySelector(".btn-all")?.addEventListener("click",
            () => html.querySelectorAll('input[name="packs"]').forEach(c => c.checked = true));
        html.querySelector(".btn-none")?.addEventListener("click",
            () => html.querySelectorAll('input[name="packs"]').forEach(c => c.checked = false));

        // Drag & drop sur la zone d'analyse
        const dropzone = html.querySelector(".drop-zone");
        if (dropzone) {
            dropzone.addEventListener("dragover", e => { e.preventDefault(); dropzone.classList.add("drag-over"); });
            dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag-over"));
            dropzone.addEventListener("drop",  e => { e.preventDefault(); dropzone.classList.remove("drag-over"); this._handleDrop(e); });
        }
    }

    async _handleDrop(event) {
        const file = event.dataTransfer.files[0];
        if (!file || !file.name.endsWith(".json")) {
            ui.notifications.warn("Déposez un fichier .json exporté depuis Foundry.");
            return;
        }
        try {
            const text = await file.text();
            const json = JSON.parse(text);
            this._analyzed     = Analyzer.analyze(json);
            this._analyzeType  = {
                docType: json.type ? "Item" : "Unknown",
                subType: json.type ?? "",
            };
            this.render(false);
        } catch (e) {
            ui.notifications.error("Impossible de lire le JSON : " + e.message);
        }
    }

    // -------------------------------------------------------------------------
    //  Actions boutons
    // -------------------------------------------------------------------------
    static async _doExport(event, target) {
        const form    = target.closest("form");
        const packIds = Array.from(form.querySelectorAll('input[name="packs"]:checked')).map(c => c.value);
        if (!packIds.length) { ui.notifications.warn("Aucun compendium sélectionné."); return; }

        this.close();
        ui.notifications.info(`🚀 Export de ${packIds.length} pack(s)…`);
        console.group("=== Crucible Exporter ===");

        let ok = 0;
        for (let i = 0; i < packIds.length; i++) {
            const pack = game.packs.get(packIds[i]);
            if (!pack) continue;
            if (i > 0) await new Promise(r => setTimeout(r, 80));
            try {
                const data = await Extractor.exportPack(pack);
                if (data) {
                    saveDataToFile(JSON.stringify(data, null, 2), "application/json", `${pack.metadata.id}.json`);
                    ok++;
                    console.log(`[${i+1}/${packIds.length}] ✅ ${pack.metadata.label}`);
                }
            } catch (err) {
                console.error(`❌ ${pack.metadata.label}`, err);
                ui.notifications.error(`Erreur sur "${pack.metadata.label}" — voir console.`);
            }
        }

        console.groupEnd();
        ui.notifications.info(`✨ ${ok}/${packIds.length} packs exportés.`);
    }

    static _switchTab(event, target) {
        this._tab = target.dataset.tab;
        this.render(false);
    }

    static _genConfig(event, target) {
        const form     = target.closest("form");
        const docType  = form.querySelector('[name="docType"]')?.value  ?? "Item";
        const subType  = form.querySelector('[name="subType"]')?.value  ?? "";
        const checked  = Array.from(form.querySelectorAll('input[name="fieldPath"]:checked')).map(c => c.value);

        if (!checked.length) { ui.notifications.warn("Cochez au moins un champ."); return; }

        const config   = Analyzer.generateConfig(docType, subType, checked);
        const fileName = `${docType.toLowerCase()}-${subType || "default"}.json`;
        saveDataToFile(JSON.stringify(config, null, 2), "application/json", fileName);
        ui.notifications.info(`✅ Config générée : ${fileName} — placez-la dans config/ et ajoutez son nom dans CONFIG_FILES.`);
    }

    // -------------------------------------------------------------------------
    //  Construction du HTML
    // -------------------------------------------------------------------------
    static _buildHTML(ctx) {
        return `
${ExporterApp._CSS}
<div class="cex-app">

    <!-- Onglets -->
    <nav class="cex-tabs">
        <button type="button" data-action="switchTab" data-tab="export"
            class="cex-tab ${ctx.tab === "export"  ? "active" : ""}">
            <i class="fa-solid fa-file-export"></i> Exporter
        </button>
        <button type="button" data-action="switchTab" data-tab="analyze"
            class="cex-tab ${ctx.tab === "analyze" ? "active" : ""}">
            <i class="fa-solid fa-magnifying-glass"></i> Analyser un document
        </button>
    </nav>

    <!-- ═══ ONGLET EXPORT ═══════════════════════════════════════════════════ -->
    ${ctx.tab === "export" ? `
    <div class="cex-scroll">
        ${Object.entries(ctx.groupedPacks).sort(([a],[b]) => a.localeCompare(b)).map(([type, packs]) => `
        <fieldset>
            <legend>${type}</legend>
            <div class="pack-grid">
                ${packs.map(p => `
                <label class="pack-row" title="${p.label}">
                    <input type="checkbox" name="packs" value="${p.id}">
                    <span class="pack-label">${p.label} <span class="pack-count">(${p.count})</span></span>
                </label>`).join("")}
            </div>
        </fieldset>`).join("")}
    </div>
    <div class="cex-footer">
        <button type="button" class="btn-all"><i class="fa-solid fa-check-double"></i> Tout</button>
        <button type="button" class="btn-none"><i class="fa-regular fa-square"></i> Rien</button>
        <button type="button" data-action="doExport" class="btn-export">
            <i class="fa-solid fa-file-export"></i> Exporter
        </button>
    </div>` : ""}

    <!-- ═══ ONGLET ANALYSER ══════════════════════════════════════════════════ -->
    ${ctx.tab === "analyze" ? `
    <div class="cex-scroll">
        <p class="cex-hint">
            <i class="fa-solid fa-circle-info"></i>
            Exportez un document depuis Foundry (clic-droit → Exporter JSON),
            puis glissez-déposez le fichier ci-dessous pour voir tous les champs disponibles.
        </p>

        <div class="drop-zone" id="cex-dropzone">
            <i class="fa-solid fa-file-arrow-down fa-2x"></i>
            <span>Glissez-déposez un fichier .json ici</span>
        </div>

        ${ctx.analyzed ? `
        <div class="cex-analyze-form">
            <div class="cex-type-row">
                <label>docType
                    <input type="text" name="docType" value="${ctx.analyzeType.docType}" placeholder="Item / Actor / JournalEntry…">
                </label>
                <label>subType
                    <input type="text" name="subType" value="${ctx.analyzeType.subType}" placeholder="talent / npc / spell…">
                </label>
            </div>

            <p class="cex-hint">Cochez les champs à inclure dans la config :</p>

            <div class="field-list">
                ${ctx.analyzed.map(f => `
                <label class="field-row ${f.isArray ? "is-array" : ""}">
                    <input type="checkbox" name="fieldPath" value="${f.path}"
                        ${["name","system.description"].includes(f.path) ? "checked" : ""}>
                    <span class="field-path">${f.path}</span>
                    <span class="field-sample" title="${f.sample}">${f.sample?.slice(0,60) ?? ""}…</span>
                </label>`).join("")}
            </div>
        </div>

        <div class="cex-footer" style="margin-top:10px">
            <button type="button" data-action="genConfig" class="btn-export">
                <i class="fa-solid fa-floppy-disk"></i> Générer le fichier de config
            </button>
        </div>
        ` : ""}
    </div>` : ""}

</div>`;
    }

    // -------------------------------------------------------------------------
    //  CSS intégré
    // -------------------------------------------------------------------------
    static _CSS = `<style>
        .cex-app { display:flex; flex-direction:column; height:100%; overflow:hidden; gap:0; }

        /* Onglets */
        .cex-tabs { display:flex; gap:4px; padding:0 0 8px 0; border-bottom:1px solid #816b66; margin-bottom:8px; }
        .cex-tab  { flex:1; padding:6px 10px; border:1px solid #816b66; border-radius:4px 4px 0 0;
                    background:rgba(0,0,0,0.05); cursor:pointer; font-size:.85rem;
                    display:flex; align-items:center; justify-content:center; gap:6px; }
        .cex-tab.active { background:rgba(129,107,102,.25); font-weight:bold; color:#cdb4a7; }
        .cex-tab:hover  { background:rgba(129,107,102,.15); }

        /* Scroll */
        .cex-scroll { flex:1; overflow-y:auto; padding-right:4px; }

        /* Packs */
        .cex-app fieldset { border:1px solid #816b66; border-radius:5px; margin:0 0 .8rem; padding:.4rem .6rem; background:rgba(0,0,0,0.04); }
        .cex-app legend   { font-weight:bold; font-size:.82rem; padding:0 4px; color:#cdb4a7; }
        .pack-grid  { display:grid; grid-template-columns:1fr 1fr; gap:3px 8px; }
        .pack-row   { display:flex; align-items:center; gap:6px; font-size:.88rem; cursor:pointer;
                      padding:2px 4px; border-radius:3px; }
        .pack-row:hover { background:rgba(0,0,0,0.06); }
        .pack-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; color:#9f8475; }
        .pack-count { opacity:.6; font-size:.76em; font-style:italic; color:brown; }

        /* Footer */
        .cex-footer { display:flex; gap:6px; padding-top:8px; border-top:1px solid #816b66; }
        .cex-footer button { flex:1; display:flex; align-items:center; justify-content:center; gap:5px;
                             font-size:.84rem; padding:6px 10px; border-radius:3px;
                             border:1px solid #816b66; cursor:pointer; transition:all .15s; }
        .cex-footer button:hover { transform:translateY(-1px); box-shadow:0 2px 5px rgba(0,0,0,.2); }
        .btn-export { font-weight:bold; }
        .btn-export:hover { background:rgba(40,167,69,.35); }

        /* Drop zone */
        .cex-hint   { font-size:.82rem; color:#9f8475; margin:.4rem 0 .8rem; line-height:1.5; }
        .drop-zone  { border:2px dashed #816b66; border-radius:6px; padding:30px;
                      text-align:center; color:#9f8475; cursor:pointer;
                      display:flex; flex-direction:column; align-items:center; gap:10px;
                      transition:all .2s; margin-bottom:12px; }
        .drop-zone.drag-over { border-color:#cdb4a7; background:rgba(205,180,167,.1); color:#cdb4a7; }

        /* Analyse */
        .cex-type-row { display:flex; gap:12px; margin-bottom:10px; }
        .cex-type-row label { flex:1; display:flex; flex-direction:column; gap:3px; font-size:.82rem; color:#9f8475; }
        .cex-type-row input { padding:4px 6px; border-radius:3px; border:1px solid #816b66; background:rgba(0,0,0,0.1); color:inherit; }

        .field-list   { display:flex; flex-direction:column; gap:2px; }
        .field-row    { display:flex; align-items:baseline; gap:8px; font-size:.82rem;
                        padding:3px 6px; border-radius:3px; cursor:pointer; }
        .field-row:hover { background:rgba(0,0,0,0.06); }
        .field-row.is-array .field-path { color:#9fc; }
        .field-path   { font-family:monospace; color:#cdb4a7; white-space:nowrap; min-width:260px; }
        .field-sample { color:#777; font-style:italic; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; }
    </style>`;
}


// =============================================================================
//  INITIALISATION
// =============================================================================

Hooks.once("ready", async () => {
    // Charge toutes les configs JSON
    await ConfigLoader.load();

    // Expose l'app globalement pour les macros
    globalThis.CrucibleExporter = {
        open: () => new ExporterApp().render(true),
    };

    console.log("CrucibleExporter | Prêt. Lancez : CrucibleExporter.open()");
});
