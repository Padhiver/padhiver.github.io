/**
 * ============================================================
 *  exporter-app.js — Interface graphique de l'exporteur
 * ============================================================
 *
 *  Ouvre une fenêtre Foundry (ApplicationV2) listant tous les
 *  compendiums disponibles avec des cases à cocher.
 *
 *  Usage depuis la console Foundry :
 *      new CrucibleExporterApp().render(true)
 *
 *  Ou via le hook déclaré dans main.js :
 *      Hooks.call("crucible-fr.openExporter")
 *
 *  ⚠️  Ce fichier ne contient que l'UI. La logique d'export est
 *      dans exporter-core.js.
 * ============================================================
 */

class CrucibleExporterApp extends foundry.applications.api.ApplicationV2 {

    constructor(options = {}) {
        super(options);
    }

    // ============================================================
    //  Options par défaut de la fenêtre
    // ============================================================
    static DEFAULT_OPTIONS = {
        id:  "crucible-exporter",
        tag: "form",
        window: {
            title:           "Export Babele — Crucible FR",
            icon:            "fa-solid fa-file-export",
            resizable:       true,
            contentClasses:  ["standard-form"],
        },
        position: { width: 700, height: 760 },
        actions:  { export: CrucibleExporterApp._onExport },
    };

    // ============================================================
    //  Préparation du contexte (liste des packs groupés par type)
    // ============================================================
    async _prepareContext(options) {
        const context = await super._prepareContext(options);

        const groupedPacks = game.packs.reduce((acc, p) => {
            let label = p.metadata.type;

            // Affine le label pour les Items selon le premier document
            if (p.metadata.type === "Item" && p.index.size > 0) {
                const first = p.index.values().next().value;
                if (first?.type) {
                    label = `Item : ${first.type.charAt(0).toUpperCase() + first.type.slice(1)}`;
                }
            }

            acc[label] ??= [];
            acc[label].push({
                id:    p.metadata.id,
                label: p.metadata.label,
                count: p.index.size,
            });
            return acc;
        }, {});

        // Tri alphabétique des groupes
        const sorted = Object.keys(groupedPacks)
            .sort()
            .reduce((acc, k) => { acc[k] = groupedPacks[k]; return acc; }, {});

        return { ...context, groupedPacks: sorted };
    }

    // ============================================================
    //  Rendu HTML
    // ============================================================
    async _renderHTML(context, options) {
        let listHtml = "";

        for (const [type, packs] of Object.entries(context.groupedPacks)) {
            listHtml += `
            <fieldset>
                <legend>${type}</legend>
                <div class="pack-grid">
                    ${packs.map(p => `
                    <label class="pack-row" title="${p.label}">
                        <input type="checkbox" name="packs" value="${p.id}">
                        <span class="pack-label">
                            ${p.label}
                            <span class="pack-count">(${p.count})</span>
                        </span>
                    </label>`).join("")}
                </div>
            </fieldset>`;
        }

        return {
            form: `
            ${CrucibleExporterApp._CSS}
            <div class="crucible-exporter">
                <div class="exporter-scroll">${listHtml}</div>
                <div class="exporter-footer">
                    <button type="button" class="btn-all">
                        <i class="fa-solid fa-check-double"></i> Tout
                    </button>
                    <button type="button" class="btn-none">
                        <i class="fa-regular fa-square"></i> Rien
                    </button>
                    <button type="button" data-action="export" class="btn-export">
                        <i class="fa-solid fa-file-export"></i> Exporter
                    </button>
                </div>
            </div>`,
        };
    }

    // ============================================================
    //  Injection dans le DOM + listeners
    // ============================================================
    _replaceHTML(result, content, options) {
        content.innerHTML = result.form;
        const boxes = content.querySelectorAll('input[name="packs"]');
        content.querySelector(".btn-all")?.addEventListener("click",  () => boxes.forEach(c => c.checked = true));
        content.querySelector(".btn-none")?.addEventListener("click", () => boxes.forEach(c => c.checked = false));
    }

    // ============================================================
    //  Action : Export
    // ============================================================
    static async _onExport(event, target) {
        const form     = target.closest("form");
        const packIds  = Array.from(form.querySelectorAll('input[name="packs"]:checked'))
                              .map(cb => cb.value);

        if (!packIds.length) {
            ui.notifications.warn("Aucun compendium sélectionné.");
            return;
        }

        this.close();

        ui.notifications.info(`🚀 Export de ${packIds.length} pack(s)…`);
        console.group("=== Crucible FR — Export Babele ===");

        let ok = 0;
        for (let i = 0; i < packIds.length; i++) {
            const pack = game.packs.get(packIds[i]);
            if (!pack) continue;

            try {
                if (i > 0) await new Promise(r => setTimeout(r, 100)); // throttle léger
                const data = await ExporterCore.exportPack(pack);
                if (data) {
                    const fileName = `${pack.metadata.id}.json`;
                    saveDataToFile(JSON.stringify(data, null, 2), "application/json", fileName);
                    ok++;
                    console.log(`[${i + 1}/${packIds.length}] ✅ ${pack.metadata.label}`);
                }
            } catch (err) {
                console.error(`[${i + 1}/${packIds.length}] ❌ ${pack.metadata.label}`, err);
                ui.notifications.error(`Erreur sur "${pack.metadata.label}" — voir la console.`);
            }
        }

        console.groupEnd();
        ui.notifications.info(`✨ Terminé : ${ok}/${packIds.length} exportés.`);
    }

    // ============================================================
    //  Styles CSS intégrés
    // ============================================================
    static _CSS = `
    <style>
        :root {
            --color-border-light-2: #816b66;
            --color-border-dark-2:  #816b66;
            --crucible-title:       #cdb4a7;
            --crucible-hint:        #9f8475;
        }

        .crucible-exporter {
            display: flex;
            flex-direction: column;
            height: 100%;
            overflow: hidden;
        }

        .exporter-scroll {
            flex: 1;
            overflow-y: auto;
            padding-right: 6px;
            margin-bottom: 6px;
        }

        .crucible-exporter fieldset {
            border: 1px solid var(--color-border-light-2);
            border-radius: 5px;
            margin: 0 0 1rem 0;
            padding: 0.5rem;
            background: rgba(0,0,0,0.05);
        }

        .crucible-exporter legend {
            font-weight: bold;
            font-size: 0.85rem;
            padding: 0 5px;
            color: var(--crucible-title);
            text-shadow: none;
        }

        .pack-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4px 10px;
        }

        .pack-row {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            padding: 2px 4px;
            border-radius: 3px;
            transition: background-color 0.15s;
        }

        .pack-row:hover { background: rgba(0,0,0,0.06); }
        .pack-row input { margin: 0; flex: 0 0 auto; cursor: pointer; }

        .pack-label {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            flex: 1;
            color: var(--crucible-hint);
        }

        .pack-count {
            opacity: 0.6;
            font-size: 0.78em;
            font-style: italic;
            color: brown;
        }

        .exporter-footer {
            display: flex;
            gap: 8px;
            padding-top: 10px;
            border-top: 1px solid var(--color-border-light-2);
        }

        .exporter-footer button {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            font-size: 0.85rem;
            padding: 6px 12px;
            border-radius: 3px;
            border: 1px solid var(--color-border-dark-2);
            cursor: pointer;
            transition: all 0.15s;
        }

        .exporter-footer button:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .btn-export { font-weight: bold; }
        .btn-export:hover { background: var(--color-level-success-hover, #28a745); }

        @media (max-width: 600px) {
            .pack-grid        { grid-template-columns: 1fr; }
            .exporter-footer  { flex-direction: column; }
        }
    </style>`;
}
