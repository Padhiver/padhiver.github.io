/**
 * ============================================================
 *  exporter-core.js — Logique d'export (sans UI)
 * ============================================================
 *
 *  Ce fichier contient uniquement la logique de transformation
 *  des documents Foundry en JSON Babele.
 *  Il ne sait rien de l'interface graphique.
 *
 *  Point d'entrée principal : ExporterCore.exportPack(pack)
 *
 *  ⚠️  Vous ne devriez PAS avoir à modifier ce fichier.
 *      Les changements de structure se font dans les fichiers config.
 * ============================================================
 */

const ExporterCore = (() => {

    // ============================================================
    //  Helpers de bas niveau
    // ============================================================

    /** Récupère une valeur via un chemin pointé ("system.actions") */
    const _get = (obj, path) => foundry.utils.getProperty(obj, path);

    /** Retourne true si la valeur est une string non vide */
    const _hasText = (v) => typeof v === "string" && v.trim().length > 0;

    // ============================================================
    //  Extraction de la description (gère string et objet)
    // ============================================================
    const _extractDescription = (desc) => {
        if (!desc) return undefined;

        if (typeof desc === "string") {
            return desc.trim() ? desc : undefined;
        }

        if (typeof desc === "object") {
            const out = {};
            // Clés typiques : value, public, private
            for (const key of ["value", "public", "private"]) {
                if (_hasText(desc[key])) out[key] = desc[key];
            }
            // Toute autre clé string non vide
            for (const [k, v] of Object.entries(desc)) {
                if (!["value", "public", "private"].includes(k) && _hasText(v)) out[k] = v;
            }
            return Object.keys(out).length ? out : undefined;
        }

        return undefined;
    };

    // ============================================================
    //  Extraction des actions (tableau avec effets imbriqués)
    // ============================================================
    const _extractActions = (actions) => {
        if (!Array.isArray(actions) || !actions.length) return undefined;
        const out = {};
        for (const action of actions) {
            if (!action?.id) continue;
            const a = {};
            if (_hasText(action.name))        a.name        = action.name;
            if (_hasText(action.description)) a.description = action.description;
            if (_hasText(action.condition))   a.condition   = action.condition;
            if (Array.isArray(action.effects)) {
                const effects = action.effects
                    .filter(e => _hasText(e?.name))
                    .map(e => ({ name: e.name }));
                if (effects.length) a.effects = effects;
            }
            if (Object.keys(a).length) out[action.id] = a;
        }
        return Object.keys(out).length ? out : undefined;
    };

    // ============================================================
    //  Extraction d'un champ générique selon sa définition FIELD
    // ============================================================
    const _extractField = (docData, fieldDef) => {
        const raw = _get(docData, fieldDef.path);
        if (raw === undefined || raw === null) return undefined;

        // Champ tableau d'objets (non-actions, ex: categories)
        if (Array.isArray(raw) && fieldDef.subFields && !["actions_converter", "adventure_items_converter"].includes(fieldDef.converter)) {
            const out = {};
            raw.forEach((el, idx) => {
                const id = el[fieldDef.idKey ?? "id"] ?? el._id ?? String(idx);
                if (!id) return;
                const t = {};
                (fieldDef.subFields ?? []).forEach(f => { if (_hasText(el[f])) t[f] = el[f]; });
                if (Object.keys(t).length) out[id] = t;
            });
            return Object.keys(out).length ? out : undefined;
        }

        // Objet direct (nested_object_converter)
        if (fieldDef.isDirectObject && typeof raw === "object" && !Array.isArray(raw)) {
            const out = {};
            (fieldDef.subFields ?? []).forEach(f => { if (_hasText(raw[f])) out[f] = raw[f]; });
            return Object.keys(out).length ? out : undefined;
        }

        // Champ simple (string brute)
        if (typeof raw === "string") return raw.trim() || undefined;

        return undefined;
    };

    // ============================================================
    //  Traduction d'un Item standard
    // ============================================================
    const getItemTranslation = (doc) => {
        const docData = doc.toObject ? doc.toObject() : doc;
        const itemType = docData.type ?? "default";
        const fields = CrucibleConfig.getItemFields(itemType);
        const t = { name: doc.name };

        for (const fieldDef of fields) {
            // description — traitement dédié
            if (fieldDef.field === "description") {
                const desc = _extractDescription(_get(docData, fieldDef.path));
                if (desc !== undefined) t.description = desc;
                continue;
            }
            // actions — traitement dédié
            if (fieldDef.field === "actions") {
                const actions = _extractActions(_get(docData, fieldDef.path));
                if (actions !== undefined) t.actions = actions;
                continue;
            }
            // champ générique
            const val = _extractField(docData, fieldDef);
            if (val !== undefined) t[fieldDef.field] = val;
        }

        return t;
    };

    // ============================================================
    //  Traduction d'un Affix (description à la racine)
    // ============================================================
    const getAffixTranslation = (doc) => {
        const docData = doc.toObject ? doc.toObject() : doc;
        const t = { name: doc.name };

        if (_hasText(docData.description)) t.description = docData.description;

        const adjective = _get(docData, "system.adjective");
        if (_hasText(adjective)) t.adjective = adjective;

        const actions = _extractActions(_get(docData, "system.actions"));
        if (actions) t.actions = actions;

        return t;
    };

    // ============================================================
    //  Traduction d'un Item (dispatch affix / standard)
    // ============================================================
    const translateItem = (item) =>
        CrucibleConfig.isAffix(item.type)
            ? getAffixTranslation(item)
            : getItemTranslation(item);

    // ============================================================
    //  Traduction d'un Actor
    // ============================================================
    const getActorTranslation = (actor) => {
        const actorData = actor.toObject ? actor.toObject() : actor;
        const actorType = actorData.type ?? "default";
        const fields    = CrucibleConfig.getActorFields(actorType);

        const t = {
            name:      actor.name,
            tokenName: actor.prototypeToken?.name ?? actor.name,
        };

        for (const fieldDef of fields) {
            // items embarqués
            if (fieldDef.field === "items" && fieldDef.isActorItem) {
                const items = actor.items;
                if (items?.size > 0) {
                    const itemsData = {};
                    items.forEach(item => { itemsData[item.name] = translateItem(item); });
                    t.items = itemsData;
                }
                continue;
            }
            // actions
            if (fieldDef.field === "actions") {
                const actions = _extractActions(_get(actorData, fieldDef.path));
                if (actions) t.actions = actions;
                continue;
            }
            // objet direct (ancestry, background…)
            if (fieldDef.isDirectObject) {
                const val = _extractField(actorData, fieldDef);
                if (val !== undefined) t[fieldDef.field] = val;
                continue;
            }
            // champ générique
            const val = _extractField(actorData, fieldDef);
            if (val !== undefined) t[fieldDef.field] = val;
        }

        return t;
    };

    // ============================================================
    //  Traduction d'un JournalEntry
    // ============================================================
    const getJournalTranslation = (doc) => {
        const docData = doc.toObject ? doc.toObject() : doc;
        const conf    = CrucibleConfig.getJournalConfig();
        const t       = { name: doc.name };

        for (const fieldDef of conf.fields ?? []) {
            const val = _extractField(docData, fieldDef);
            if (val !== undefined) t[fieldDef.field] = val;
        }

        if (conf.exportPages && doc.pages?.size) {
            const pages = {};
            doc.pages.forEach(p => {
                const pTrans = { name: p.name };
                if (p.text?.content?.trim()) pTrans.text = p.text.content;
                pages[p.name] = pTrans;
            });
            if (Object.keys(pages).length) t.pages = pages;
        }

        return t;
    };

    // ============================================================
    //  Traduction d'une Adventure
    // ============================================================
    const getAdventureTranslation = (doc) => {
        const conf = CrucibleConfig.getAdventureConfig();
        const t    = { name: doc.name };

        if (_hasText(doc.caption))     t.caption     = doc.caption;
        if (_hasText(doc.description)) t.description = doc.description;

        // Champs top-level additionnels
        const docData = doc.toObject ? doc.toObject() : doc;
        for (const fieldDef of conf.topLevelFields ?? []) {
            const val = _extractField(docData, fieldDef);
            if (val !== undefined) t[fieldDef.field] = val;
        }

        if (conf.exportScenes && doc.scenes?.size) {
            t.scenes = {};
            doc.scenes.forEach(s => { t.scenes[s.name] = { name: s.name }; });
        }

        if (conf.exportMacros && doc.macros?.size) {
            t.macros = {};
            doc.macros.forEach(m => { t.macros[m.name] = { name: m.name, command: m.command }; });
        }

        if (conf.exportFolders && doc.folders?.size) {
            t.folders = {};
            doc.folders.forEach(f => { t.folders[f.name] = f.name; });
        }

        if (conf.exportJournals && doc.journal?.size) {
            t.journals = {};
            doc.journal.forEach(j => { t.journals[j.name] = getJournalTranslation(j); });
        }

        if (doc.actors?.size) {
            t.actors = {};
            doc.actors.forEach(actor => {
                const actorTrans = getActorTranslation(actor);
                if (t.actors[actor.name]) foundry.utils.mergeObject(t.actors[actor.name], actorTrans, { recursive: true });
                else t.actors[actor.name] = actorTrans;
            });
        }

        if (doc.items?.size) {
            t.items = {};
            doc.items.forEach(item => { t.items[item.name] = translateItem(item); });
        }

        return t;
    };

    // ============================================================
    //  Export d'un pack complet
    // ============================================================
    const exportPack = async (pack) => {
        const documents = await pack.getDocuments();
        if (!documents.length) return null;

        const entriesData = {};
        const foldersData = {};

        // Collecte des dossiers
        const collectFolders = (folder) => {
            if (!folder) return;
            foldersData[folder.name] = folder.name;
            folder.children?.forEach(child => { if (child.folder) collectFolders(child.folder); });
        };
        pack.folders?.forEach(f => collectFolders(f));

        // Type global du pack
        const packType = pack.metadata.type;

        for (const doc of documents) {
            let translation;

            if (packType === "Adventure") {
                translation = getAdventureTranslation(doc);
            } else if (packType === "JournalEntry") {
                translation = getJournalTranslation(doc);
            } else if (packType === "Actor") {
                translation = getActorTranslation(doc);
            } else {
                // Item (talent, spell, consumable, affix, etc.)
                translation = translateItem(doc);
            }

            if (entriesData[doc.name]) {
                foundry.utils.mergeObject(entriesData[doc.name], translation, { recursive: true });
            } else {
                entriesData[doc.name] = translation;
            }
        }

        // Tri alphabétique
        const sortedEntries = Object.keys(entriesData)
            .sort((a, b) => a.localeCompare(b))
            .reduce((acc, key) => { acc[key] = entriesData[key]; return acc; }, {});

        return {
            label:   pack.metadata.label,
            folders: foldersData,
            entries: sortedEntries,
        };
    };

    // API publique
    return { exportPack, translateItem, getActorTranslation, getJournalTranslation, getAffixTranslation };

})();
