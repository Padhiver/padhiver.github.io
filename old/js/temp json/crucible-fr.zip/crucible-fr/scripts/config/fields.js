/**
 * ============================================================
 *  fields.js — Blocs de champs réutilisables
 * ============================================================
 *
 *  C'est ici que vous déclarez des "briques" que vous pouvez
 *  ensuite combiner dans les configs par type de document.
 *
 *  Un "FieldBlock" est un objet { field, path, converter?, subFields?, ... }
 *  qui correspond exactement à ce que Babele attend dans ses mappings.
 *
 *  ➕ AJOUTER UN NOUVEAU CHAMP :
 *     1. Définissez un FieldBlock ci-dessous (ou ajoutez-en un inline dans la config).
 *     2. Référencez-le dans le fichier de config voulu (item.config.js, actor.config.js…).
 *     C'est tout.
 *
 *  Exemple rapide — vous voulez exporter system.description.tralala sur les Items :
 *     → Allez dans item.config.js et ajoutez dans exportFields :
 *         FIELDS.DESCRIPTION_TRALALA
 *     → Puis définissez FIELDS.DESCRIPTION_TRALALA ici :
 *         DESCRIPTION_TRALALA: {
 *             field: "tralala",
 *             path: "system.description.tralala",
 *             // pas de converter → valeur brute copiée telle quelle
 *         }
 * ============================================================
 */

const FIELDS = {

    // ----------------------------------------------------------
    //  Champs simples (pas de converter, valeur copiée directement)
    // ----------------------------------------------------------

    /** system.description — string ou objet {public, private, value} */
    DESCRIPTION: {
        field: "description",
        path: "system.description",
        converter: "description_converter",
    },

    /** system.adjective — string (utilisé par les affixes) */
    ADJECTIVE: {
        field: "adjective",
        path: "system.adjective",
        // pas de converter : string brute
    },

    // ----------------------------------------------------------
    //  Champs tableau (actions, avec effets imbriqués)
    // ----------------------------------------------------------

    /** system.actions — tableau d'actions {id, name, description, condition, effects[]} */
    ACTIONS: {
        field: "actions",
        path: "system.actions",
        converter: "actions_converter",
        subFields: ["name", "description", "condition"],
        idKey: "id",
    },

    /** system.actions sans champ "condition" (ex : consumables) */
    ACTIONS_NO_CONDITION: {
        field: "actions",
        path: "system.actions",
        converter: "actions_converter",
        subFields: ["name", "description"],
        idKey: "id",
    },

    // ----------------------------------------------------------
    //  Champs objets imbriqués (nested_object_converter)
    //  path = chemin, subFields = clés à extraire
    // ----------------------------------------------------------

    ANCESTRY: {
        field: "ancestry",
        path: "system.details.ancestry",
        converter: "nested_object_converter",
        subFields: ["name", "description"],
        isDirectObject: true,
    },

    BACKGROUND: {
        field: "background",
        path: "system.details.background",
        converter: "nested_object_converter",
        subFields: ["name", "description"],
        isDirectObject: true,
    },

    BIOGRAPHY: {
        field: "biography",
        path: "system.details.biography",
        converter: "nested_object_converter",
        subFields: ["appearance", "public", "private"],
        isDirectObject: true,
    },

    ARCHETYPE: {
        field: "archetype",
        path: "system.details.archetype",
        converter: "nested_object_converter",
        subFields: ["name", "description"],
        isDirectObject: true,
    },

    TAXONOMY: {
        field: "taxonomy",
        path: "system.details.taxonomy",
        converter: "nested_object_converter",
        subFields: ["name", "description"],
        isDirectObject: true,
    },

    // ----------------------------------------------------------
    //  Champs spéciaux (items imbriqués dans actors / adventures)
    // ----------------------------------------------------------

    /** Items portés par un Actor */
    ACTOR_ITEMS: {
        field: "items",
        path: "items",
        converter: "adventure_items_converter",
        subFields: ["name", "description", "actions"],
        idKey: "id",
        isActorItem: true,
    },

    // ----------------------------------------------------------
    //  ➕ AJOUTEZ VOS PROPRES CHAMPS ICI
    //  Copiez le bloc qui ressemble le plus à votre besoin et
    //  adaptez field, path, converter, subFields.
    // ----------------------------------------------------------

};
