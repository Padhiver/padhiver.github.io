/**
 * ============================================================
 *  config/index.js — Façade centrale des configurations
 * ============================================================
 *
 *  Ce fichier agrège ITEM_CONFIG, ACTOR_CONFIG, JOURNAL_CONFIG
 *  et ADVENTURE_CONFIG en un objet CONFIG unique utilisé par
 *  l'exporteur et le générateur de mappings.
 *
 *  Il expose aussi CrucibleConfig.generateMappings() qui produit
 *  l'objet mappings.json à partir des configs déclarées.
 *
 *  ⚠️  Vous ne devriez PAS avoir à modifier ce fichier.
 *      Modifiez les fichiers *config.js ou fields.js à la place.
 * ============================================================
 */

const CrucibleConfig = (() => {

    // ----------------------------------------------------------------
    //  Résolution d'un type : retourne la config ou le "default"
    // ----------------------------------------------------------------
    const resolve = (configMap, type) =>
        configMap[type] ?? configMap["default"] ?? { fields: [] };

    // ----------------------------------------------------------------
    //  Récupère les fields d'un Item selon son type
    // ----------------------------------------------------------------
    const getItemFields = (itemType) => resolve(ITEM_CONFIG, itemType).fields ?? [];

    // ----------------------------------------------------------------
    //  Récupère les fields d'un Actor selon son type
    // ----------------------------------------------------------------
    const getActorFields = (actorType) => resolve(ACTOR_CONFIG, actorType).fields ?? [];

    // ----------------------------------------------------------------
    //  Indique si le type d'item est un affix
    // ----------------------------------------------------------------
    const isAffix = (itemType) => !!(ITEM_CONFIG[itemType]?.isAffix);

    // ----------------------------------------------------------------
    //  Config Journal
    // ----------------------------------------------------------------
    const getJournalConfig = () => resolve(JOURNAL_CONFIG, "default");

    // ----------------------------------------------------------------
    //  Config Adventure
    // ----------------------------------------------------------------
    const getAdventureConfig = () => resolve(ADVENTURE_CONFIG, "default");

    // ----------------------------------------------------------------
    //  Génère l'objet mappings.json à partir des configs déclarées.
    //  Appelé par main.js au démarrage (log console) et par l'exporter.
    // ----------------------------------------------------------------
    const generateMappings = () => {
        const mappings = {};

        // ---- Item --------------------------------------------------
        const itemFields = {};
        // On prend l'union de tous les fields déclarés dans ITEM_CONFIG
        const seenItemFields = new Set();
        for (const conf of Object.values(ITEM_CONFIG)) {
            for (const f of (conf.fields ?? [])) {
                if (!seenItemFields.has(f.field)) {
                    seenItemFields.add(f.field);
                    if (f.converter) {
                        itemFields[f.field] = { path: f.path, converter: f.converter };
                    } else {
                        itemFields[f.field] = f.path;
                    }
                }
            }
        }
        if (Object.keys(itemFields).length) mappings["Item"] = itemFields;

        // ---- Actor -------------------------------------------------
        const actorFields = {};
        const seenActorFields = new Set();
        for (const conf of Object.values(ACTOR_CONFIG)) {
            for (const f of (conf.fields ?? [])) {
                if (!seenActorFields.has(f.field)) {
                    seenActorFields.add(f.field);
                    if (f.converter) {
                        actorFields[f.field] = { path: f.path, converter: f.converter };
                    } else {
                        actorFields[f.field] = f.path;
                    }
                }
            }
        }
        if (Object.keys(actorFields).length) mappings["Actor"] = actorFields;

        // ---- JournalEntry ------------------------------------------
        const journalConf = getJournalConfig();
        const journalFields = {};
        for (const f of (journalConf.fields ?? [])) {
            if (f.converter) {
                journalFields[f.field] = { path: f.path, converter: f.converter };
            } else {
                journalFields[f.field] = f.path;
            }
        }
        if (Object.keys(journalFields).length) mappings["JournalEntry"] = journalFields;

        // ---- Adventure ---------------------------------------------
        //  L'Adventure délègue aux configs Actor et Item,
        //  on expose juste les conteneurs vides comme Babele les attend.
        mappings["Adventure"] = {
            actors: Object.keys(actorFields).length
                ? { ...actorFields }
                : {},
            items:    {},
            journals: {},
            scenes:   {},
            macros:   {},
        };

        return mappings;
    };

    // API publique
    return {
        getItemFields,
        getActorFields,
        isAffix,
        getJournalConfig,
        getAdventureConfig,
        generateMappings,
        // Accès direct aux configs brutes si besoin
        raw: { ITEM_CONFIG, ACTOR_CONFIG, JOURNAL_CONFIG, ADVENTURE_CONFIG },
    };

})();
