/**
 * ============================================================
 *  journal.config.js — Configuration des JournalEntry
 * ============================================================
 *
 *  Les pages d'un JournalEntry sont toujours exportées
 *  automatiquement (name + text.content).
 *  Ajoutez ici les champs supplémentaires si nécessaire.
 * ============================================================
 */

const JOURNAL_CONFIG = {

    default: {
        fields: [
            {
                field: "categories",
                path: "categories",
                converter: "categories_converter",
                subFields: ["name"],
                idKey: "_id",
            },
        ],
        // Les pages sont exportées automatiquement, pas besoin de les lister.
        exportPages: true,
    },

    // ----------------------------------------------------------
    //  ➕ AJOUTEZ DES TYPES DE JOURNAL ICI SI NÉCESSAIRE
    // ----------------------------------------------------------

};
