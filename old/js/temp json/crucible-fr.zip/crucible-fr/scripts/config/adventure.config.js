/**
 * ============================================================
 *  adventure.config.js — Configuration des Adventures
 * ============================================================
 *
 *  Une Adventure est un document conteneur. Elle exporte :
 *    - ses métadonnées (name, caption, description)
 *    - ses scenes, macros, folders (toujours, automatiquement)
 *    - ses journals (pages incluses, automatiquement)
 *    - ses actors  → utilise ACTOR_CONFIG pour chaque actor
 *    - ses items   → utilise ITEM_CONFIG pour chaque item
 *
 *  Vous n'avez normalement pas à toucher ce fichier souvent.
 *  Pour changer ce qui est exporté dans les actors/items d'une
 *  Adventure, modifiez actor.config.js / item.config.js.
 * ============================================================
 */

const ADVENTURE_CONFIG = {

    default: {
        // Champs de l'Adventure elle-même (hors actors/items/journals/scenes/macros)
        topLevelFields: [
            // { field: "synopsis", path: "system.synopsis" },  // exemple
        ],

        // Faut-il exporter scenes, macros, folders, journals ?
        exportScenes:  true,
        exportMacros:  true,
        exportFolders: true,
        exportJournals: true,

        // Les actors et items de l'Adventure utilisent automatiquement
        // ACTOR_CONFIG et ITEM_CONFIG → rien à changer ici.
    },

};
