/**
 * ============================================================
 *  actor.config.js — Configuration des Actors
 * ============================================================
 *
 *  Même principe qu'item.config.js, mais pour les Actors.
 *  Un Actor exporte toujours : name, tokenName, puis les champs listés.
 *  Les items portés par l'Actor sont gérés automatiquement
 *  via FIELDS.ACTOR_ITEMS si vous l'incluez.
 *
 *  ➕ AJOUTER UN CHAMP ACTOR :
 *     1. Définissez le FIELD dans fields.js si besoin.
 *     2. Ajoutez FIELDS.MON_CHAMP dans le tableau fields ci-dessous.
 * ============================================================
 */

const ACTOR_CONFIG = {

    // ---- character (PJ) ---------------------------------------
    character: {
        fields: [
            FIELDS.ACTOR_ITEMS,
            FIELDS.ACTIONS,
            FIELDS.ANCESTRY,
            FIELDS.BACKGROUND,
            FIELDS.BIOGRAPHY,
            FIELDS.ARCHETYPE,
            FIELDS.TAXONOMY,
        ],
    },

    // ---- npc (PNJ) --------------------------------------------
    npc: {
        fields: [
            FIELDS.ACTOR_ITEMS,
            FIELDS.ACTIONS,
            FIELDS.ANCESTRY,
            FIELDS.BIOGRAPHY,
            FIELDS.TAXONOMY,
        ],
    },

    // ---- DEFAULT (type inconnu) --------------------------------
    default: {
        fields: [
            FIELDS.ACTOR_ITEMS,
            FIELDS.ACTIONS,
        ],
    },

    // ----------------------------------------------------------
    //  ➕ AJOUTEZ VOS TYPES D'ACTOR ICI
    // ----------------------------------------------------------

};
