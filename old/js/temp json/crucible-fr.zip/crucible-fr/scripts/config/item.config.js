/**
 * ============================================================
 *  item.config.js — Configuration des Items
 * ============================================================
 *
 *  Chaque entrée de ITEM_CONFIG correspond à un type d'Item
 *  (tel que retourné par doc.type dans Foundry).
 *
 *  Structure d'une entrée :
 *  {
 *      exportFields : [...FIELDS.*]   // champs à inclure dans l'export JSON
 *      mappingFields: [...FIELDS.*]   // champs à déclarer dans mappings.json
 *                                     // (souvent identiques à exportFields)
 *  }
 *
 *  Si exportFields === mappingFields vous pouvez n'écrire que "fields".
 *
 *  ➕ AJOUTER UN TYPE D'ITEM :
 *     Ajoutez simplement une clé avec le type exact (ex: "weapon")
 *     et listez les FIELDS.* dont vous avez besoin.
 *     Si ce type partage la même config qu'un autre, pointez vers
 *     le même tableau : weapon: ITEM_CONFIG.talent
 * ============================================================
 */

const ITEM_CONFIG = {

    // ---- talent -----------------------------------------------
    talent: {
        fields: [
            FIELDS.DESCRIPTION,
            FIELDS.ACTIONS,
        ],
    },

    // ---- spell ------------------------------------------------
    spell: {
        fields: [
            FIELDS.DESCRIPTION,
            FIELDS.ACTIONS,
        ],
    },

    // ---- consumable -------------------------------------------
    consumable: {
        fields: [
            FIELDS.DESCRIPTION,
            FIELDS.ACTIONS_NO_CONDITION,
        ],
    },

    // ---- affix ------------------------------------------------
    //  L'affix a une description à la RACINE du doc (pas dans system),
    //  et un adjective dans system. La logique spéciale est dans
    //  exporter-core.js (getAffixTranslation).
    //  On laisse fields vide ici pour signifier "pas de champ générique".
    affix: {
        fields: [],
        isAffix: true,   // flag lu par l'exporteur pour appeler getAffixTranslation()
    },

    // ---- DEFAULT (type inconnu) --------------------------------
    //  Si un Item ne correspond à aucun type ci-dessus, on exporte
    //  au minimum le nom + description brute.
    default: {
        fields: [
            FIELDS.DESCRIPTION,
        ],
    },

    // ----------------------------------------------------------
    //  ➕ AJOUTEZ VOS TYPES ICI
    // ----------------------------------------------------------
    // weapon: {
    //     fields: [
    //         FIELDS.DESCRIPTION,
    //         FIELDS.ACTIONS,
    //         { field: "damage", path: "system.damage" },  // champ inline ad-hoc
    //     ],
    // },

};
