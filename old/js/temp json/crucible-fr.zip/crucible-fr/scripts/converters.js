/**
 * ============================================================
 *  converters.js — Convertisseurs Babele
 * ============================================================
 *
 *  Chaque convertisseur est une fonction pure :
 *      (originalValue, translationValue) => newValue
 *
 *  Ils sont enregistrés dans Babele via babele.registerConverters()
 *  dans main.js.
 *
 *  ➕ AJOUTER UN CONVERTISSEUR :
 *     1. Écrivez votre fonction ici.
 *     2. Ajoutez-la dans l'objet CONVERTERS en bas de fichier.
 *     3. Référencez son nom (string) dans fields.js : converter: "mon_converter"
 * ============================================================
 */

// ----------------------------------------------------------------
//  Utilitaires internes
// ----------------------------------------------------------------

/**
 * Normalise n'importe quelle collection en tableau.
 * Gère : Array, Map, EmbeddedCollection (avec .contents), itérables, objets.
 */
const _asArray = (collection) => {
    if (!collection) return [];
    if (Array.isArray(collection)) return collection;
    if (collection instanceof Map) return Array.from(collection.values());
    if (Array.isArray(collection.contents)) return collection.contents;
    if (typeof collection[Symbol.iterator] === "function" && typeof collection !== "string") {
        return Array.from(collection);
    }
    if (typeof collection === "object") return Object.values(collection);
    return [];
};

/**
 * Cherche une traduction dans un tableau ou un objet de traductions.
 * Essaie id, _id, name, label — puis repli sur l'index si tableau.
 */
const _findTranslation = (source, translations, index = -1) => {
    if (!source || !translations) return null;
    const keys = [source.id, source._id, source.name, source.label].filter(Boolean);

    if (Array.isArray(translations)) {
        for (const key of keys) {
            const found = translations.find(
                (entry) =>
                    entry &&
                    typeof entry === "object" &&
                    (entry.id === key || entry._id === key || entry.name === key || entry.label === key)
            );
            if (found) return found;
        }
        return translations[index] ?? null;
    }

    if (typeof translations === "object") {
        for (const key of keys) {
            if (translations[key]) return translations[key];
        }
    }
    return null;
};

// ----------------------------------------------------------------
//  Convertisseurs
// ----------------------------------------------------------------

/**
 * description_converter
 * ─────────────────────
 * Gère trois cas :
 *  • string  → remplacement direct
 *  • objet   → fusion clé par clé (ex : {public, private})
 *  • null    → retourne l'original intact
 */
const descriptionConverter = (original, translation) => {
    if (translation === undefined || translation === null) return original;
    if (typeof translation === "string") return translation;
    if (typeof translation === "object" && !Array.isArray(translation)) {
        const result = original && typeof original === "object" ? { ...original } : {};
        for (const [key, value] of Object.entries(translation)) {
            if (value !== undefined) result[key] = value;
        }
        return result;
    }
    return original;
};

/**
 * actions_converter
 * ─────────────────
 * Traduit un tableau d'actions {id, name, description, condition, effects[]}.
 * Cherche chaque action par id/name dans les traductions.
 */
const actionsConverter = (actions, translations) => {
    if (!actions || !translations) return actions;
    const arr = _asArray(actions);
    for (const [index, action] of arr.entries()) {
        if (!action) continue;
        const translation = _findTranslation(action, translations, index);
        if (!translation || typeof translation !== "object") continue;

        if (translation.name        !== undefined) action.name        = translation.name;
        if (translation.description !== undefined) action.description = translation.description;
        if (translation.condition   !== undefined) action.condition   = translation.condition;

        // Effets imbriqués dans l'action
        if (translation.effects && Array.isArray(action.effects)) {
            action.effects = action.effects.map((effect, idx) => {
                const effectTrans = translation.effects[idx];
                if (effectTrans?.name) effect.name = effectTrans.name;
                return effect;
            });
        }
    }
    return actions;
};

/**
 * adventure_items_converter
 * ─────────────────────────
 * Traduit les items embarqués dans un Actor ou une Adventure.
 * Délègue description → descriptionConverter et actions → actionsConverter.
 */
const adventureItemsConverter = (items, translations) => {
    if (!items || !translations) return items;
    const arr = _asArray(items);
    for (const [index, item] of arr.entries()) {
        if (!item) continue;
        const itemTranslation = _findTranslation(item, translations, index);
        if (!itemTranslation || typeof itemTranslation !== "object") continue;

        if (itemTranslation.name !== undefined) item.name = itemTranslation.name;

        if (itemTranslation.description !== undefined) {
            item.system ??= {};
            item.system.description = descriptionConverter(
                item.system.description,
                itemTranslation.description
            );
        }

        if (itemTranslation.actions && item.system?.actions) {
            item.system.actions = actionsConverter(item.system.actions, itemTranslation.actions);
        }
    }
    return items;
};

/**
 * categories_converter
 * ────────────────────
 * Traduit le tableau de catégories d'un JournalEntry.
 */
const categoriesConverter = (categories, translations) => {
    if (!categories || !translations) return categories;
    const arr = _asArray(categories);
    for (const [index, item] of arr.entries()) {
        if (!item) continue;
        const translation = _findTranslation(item, translations, index);
        if (translation?.name !== undefined) item.name = translation.name;
    }
    return categories;
};

/**
 * nested_object_converter
 * ───────────────────────
 * Fusionne un objet de traduction clé par clé dans l'objet original.
 * Utilisé pour ancestry, background, biography, archetype, taxonomy.
 */
const nestedObjectConverter = (obj, translations) => {
    if (
        !obj ||
        typeof obj !== "object" ||
        Array.isArray(obj) ||
        !translations ||
        typeof translations !== "object"
    ) {
        return obj;
    }
    for (const [key, value] of Object.entries(translations)) {
        if (value !== undefined) obj[key] = value;
    }
    return obj;
};

// ----------------------------------------------------------------
//  Export — noms utilisés dans fields.js (converter: "xxx")
// ----------------------------------------------------------------
const CONVERTERS = {
    "description_converter":        descriptionConverter,
    "actions_converter":            actionsConverter,
    "adventure_items_converter":    adventureItemsConverter,
    "categories_converter":         categoriesConverter,
    "nested_object_converter":      nestedObjectConverter,

    // ➕ Ajoutez vos convertisseurs ici et dans fields.js
};
