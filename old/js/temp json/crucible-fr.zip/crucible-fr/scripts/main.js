/**
 * ============================================================
 *  main.js — Point d'entrée du module Crucible FR
 * ============================================================
 *
 *  Ce fichier :
 *    1. Enregistre le module auprès de Babele (hook babele.init)
 *    2. Enregistre tous les convertisseurs (depuis converters.js)
 *    3. Expose la commande d'export dans la console Foundry
 *    4. Initialise les petites traductions i18n système
 *
 *  ⚠️  Vous ne devriez PAS avoir à modifier ce fichier.
 * ============================================================
 */

// ----------------------------------------------------------------
//  Hook Babele : enregistrement du module + convertisseurs
// ----------------------------------------------------------------
Hooks.once("babele.init", (babele) => {
    if (!game.modules.get("babele")?.active) return;

    // 1. Enregistrement du module
    babele.register({
        module: "crucible-fr",
        lang:   "fr",
        dir:    "compendium/fr",
    });

    // 2. Enregistrement des convertisseurs (définis dans converters.js)
    babele.registerConverters(CONVERTERS);

    // 3. Log de confirmation + mappings générés dynamiquement
    console.groupCollapsed("Crucible FR | Module chargé ✅");
    console.log("Convertisseurs :", Object.keys(CONVERTERS));
    console.log("Mappings générés :", CrucibleConfig.generateMappings());
    console.groupEnd();
});

// ----------------------------------------------------------------
//  Hook i18n : petits textes système
// ----------------------------------------------------------------
Hooks.once("i18nInit", () => {
    game.i18n.translations.Sort = "Sort";
    game.i18n.translations.sort = "tri";
});

// ----------------------------------------------------------------
//  Exposition globale de l'exporteur pour usage en console/macro
//
//  Usage :
//      crucibleFR.openExporter()
//      crucibleFR.exportPack(game.packs.get("mon-pack-id"))
//      crucibleFR.config.generateMappings()
// ----------------------------------------------------------------
Hooks.once("ready", () => {
    globalThis.crucibleFR = {
        /** Ouvre la fenêtre d'export graphique */
        openExporter: () => new CrucibleExporterApp().render(true),

        /** Exporte un pack directement et télécharge le JSON */
        exportPack: async (pack) => {
            if (!pack) { ui.notifications.error("Pack invalide."); return; }
            ui.notifications.info(`Export de "${pack.metadata.label}"…`);
            try {
                const data = await ExporterCore.exportPack(pack);
                if (data) {
                    saveDataToFile(JSON.stringify(data, null, 2), "application/json", `${pack.metadata.id}.json`);
                    ui.notifications.info(`✅ "${pack.metadata.label}" exporté.`);
                }
            } catch (err) {
                console.error("Erreur d'export :", err);
                ui.notifications.error(`Erreur : ${err.message}`);
            }
        },

        /** Accès aux configs et utilitaires */
        config: CrucibleConfig,
    };

    console.log("Crucible FR | Commandes disponibles : crucibleFR.openExporter() | crucibleFR.exportPack(pack) | crucibleFR.config");
});
