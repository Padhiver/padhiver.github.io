# Crucible FR — Module de traduction Babele

## Structure des fichiers

```
crucible-fr/
├── module.json                      ← Manifeste Foundry
├── lang/fr.json                     ← Traductions UI du module
├── compendium/fr/
│   ├── mappings.json                ← Mappings Babele (généré, ne pas éditer)
│   └── *.json                       ← Vos fichiers de traduction par pack
└── scripts/
    ├── main.js                      ← Point d'entrée (hooks, init)
    ├── converters.js                ← Convertisseurs Babele
    ├── config/
    │   ├── fields.js                ← ⭐ Définitions de champs réutilisables
    │   ├── item.config.js           ← ⭐ Config par type d'Item
    │   ├── actor.config.js          ← ⭐ Config par type d'Actor
    │   ├── journal.config.js        ← Config des JournalEntry
    │   ├── adventure.config.js      ← Config des Adventures
    │   └── index.js                 ← Façade (ne pas éditer)
    └── exporter/
        ├── exporter-core.js         ← Logique d'export (ne pas éditer)
        └── exporter-app.js          ← Interface graphique (ne pas éditer)
```

---

## Utilisation

### Ouvrir l'exporteur graphique
Dans la **console Foundry** (F12) :
```js
crucibleFR.openExporter()
```
Cochez les packs voulus, cliquez **Exporter** → un JSON par pack est téléchargé.

### Exporter un seul pack directement
```js
crucibleFR.exportPack(game.packs.get("crucible.talents"))
```

### Voir les mappings actuels
```js
crucibleFR.config.generateMappings()
```

---

## ➕ Ajouter un champ à exporter

### Cas 1 — Champ simple sur un Item existant

**Exemple : exporter `system.description.tralala` sur les talents.**

**Étape 1** — Déclarez le champ dans `scripts/config/fields.js` :
```js
DESCRIPTION_TRALALA: {
    field: "tralala",
    path:  "system.description.tralala",
    // pas de converter → string brute copiée telle quelle
},
```

**Étape 2** — Ajoutez-le dans `scripts/config/item.config.js` sous `talent` :
```js
talent: {
    fields: [
        FIELDS.DESCRIPTION,
        FIELDS.ACTIONS,
        FIELDS.DESCRIPTION_TRALALA,   // ← ajout
    ],
},
```

C'est tout. L'export et le mapping sont mis à jour automatiquement.

---

### Cas 2 — Nouveau type d'Item

Ajoutez une entrée dans `item.config.js` :
```js
weapon: {
    fields: [
        FIELDS.DESCRIPTION,
        FIELDS.ACTIONS,
        { field: "damage", path: "system.damage" },  // champ ad-hoc inline
    ],
},
```

---

### Cas 3 — Nouveau convertisseur

1. Écrivez la fonction dans `converters.js`
2. Ajoutez-la dans l'objet `CONVERTERS` en bas du fichier
3. Référencez son nom dans `fields.js` : `converter: "mon_converter"`

---

## Fichiers à ne PAS modifier

| Fichier | Raison |
|---|---|
| `scripts/config/index.js` | Façade automatique — toute modif manuelle sera écrasée |
| `scripts/exporter/exporter-core.js` | Logique générique — modifiez les configs à la place |
| `compendium/fr/mappings.json` | Généré par `CrucibleConfig.generateMappings()` |

---

## Fichiers ⭐ à modifier selon vos besoins

| Fichier | Quand y toucher |
|---|---|
| `scripts/config/fields.js` | Ajouter/modifier un champ exportable |
| `scripts/config/item.config.js` | Ajouter/modifier un type d'Item |
| `scripts/config/actor.config.js` | Ajouter/modifier un type d'Actor |
| `scripts/converters.js` | Ajouter un convertisseur personnalisé |
